
var stevejobsWW = [{
	"id": "b69e0027-588b-35b2-8ccd-e7a07e2f3d90",
	"level": "0",
	"type": "Work",
	"genre" : "Non-fiction",
	"title": "Steve Jobs",
	"form" : "Biography",
	"aut": [{
		"role": "Author",
		"name": "Isaacson, Walter",
	}],
	"children": [{
		"id": "0.1.1",
		"level": "1",
		"type": "Category",
		"subtype": "P2051",
		"label": "Adaptations",
		"_children": [{
			"id": "0.1.1.1",
			"level": "2",
			"type": "Category",
			"subtype": "Motion picture",
			"label": "Motion picture",
			"dchildren": [{
				"id": "6603f266-1751-39c8-b7b5-9de17584de4f",
				"level": "3",
				"type": "Work",
				"genre" : "Biographical films.",
				"date": "2009",
				"title": "Steve Jobs",
				"form" : "Motion picture",
				"actor": [{
					"role": "actor",
					"name": "Kutcher, Ashton",
					"date": "1978-"
				}
				,{
					"role": "actor",
					"name": "Mulroney, Dermot",
				}
				,{
					"role": "actor",
					"name": "Gad, Josh",
					"date": "1981-"
				}],
				"aus": [{
					"role": "Screenplay",
					"name": "Whiteley, Matt",
				}],
				"drt": [{
					"role": "Director",
					"name": "Stern, Joshua Michael",
				}],
			}]
		}]
	}]
}];